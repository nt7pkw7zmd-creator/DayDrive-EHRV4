import "dotenv/config";
import pg from "pg";
import argon2 from "argon2";

const { Pool } = pg;
const required = ["DATABASE_URL", "BOOTSTRAP_ADMIN_USERNAME", "BOOTSTRAP_ADMIN_NAME", "BOOTSTRAP_ADMIN_PASSWORD"];
for (const key of required) {
  if (!process.env[key]) throw new Error(`${key} is required for one-time admin provisioning`);
}
const username = process.env.BOOTSTRAP_ADMIN_USERNAME.trim().toLowerCase();
const displayName = process.env.BOOTSTRAP_ADMIN_NAME.trim();
const password = process.env.BOOTSTRAP_ADMIN_PASSWORD;
if (!/^[a-z0-9._-]{3,64}$/.test(username)) throw new Error("Username must be 3–64 lowercase letters, digits, dots, underscores, or hyphens");
if (password.length < 14) throw new Error("Bootstrap password must be at least 14 characters");

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
try {
  const existing = await pool.query("SELECT id FROM app_users WHERE role='admin' LIMIT 1");
  if (existing.rowCount) throw new Error("An administrator already exists; bootstrap is disabled");
  const passwordHash = await argon2.hash(password, { type: argon2.argon2id });
  await pool.query(
    "INSERT INTO app_users (username, display_name, password_hash, role) VALUES ($1,$2,$3,'admin')",
    [username, displayName, passwordHash]
  );
  console.log(`Created the initial DayDrive EHR administrator: ${username}`);
} finally {
  await pool.end();
}
