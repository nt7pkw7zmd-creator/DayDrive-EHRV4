import test from "node:test";
import assert from "node:assert/strict";
import { canReadAssignment, canGradeAssignment, hashAuditEvent } from "../src/security.js";

const assignment = { id: "a1", created_by: "teacher-1", assigned_to: "student-1" };

test("student can read only their own assignment", () => {
  assert.equal(canReadAssignment({ id: "student-1", role: "student" }, assignment), true);
  assert.equal(canReadAssignment({ id: "student-2", role: "student" }, assignment), false);
});

test("instructor can read and grade only assignments they created", () => {
  assert.equal(canReadAssignment({ id: "teacher-1", role: "instructor" }, assignment), true);
  assert.equal(canReadAssignment({ id: "teacher-2", role: "instructor" }, assignment), false);
  assert.equal(canGradeAssignment({ id: "teacher-1", role: "instructor" }, assignment), true);
  assert.equal(canGradeAssignment({ id: "teacher-2", role: "instructor" }, assignment), false);
});

test("admin can read and grade all assignments", () => {
  assert.equal(canReadAssignment({ id: "admin-1", role: "admin" }, assignment), true);
  assert.equal(canGradeAssignment({ id: "admin-1", role: "admin" }, assignment), true);
});

test("unknown roles and missing actors are denied", () => {
  assert.equal(canReadAssignment({ id: "x", role: "guest" }, assignment), false);
  assert.equal(canReadAssignment(null, assignment), false);
  assert.equal(canGradeAssignment({ id: "student-1", role: "student" }, assignment), false);
});

test("audit hash changes when event content changes", () => {
  const base = { occurredAt: "2026-11-12T00:00:00.000Z", actorRole: "student", action: "login", metadata: {} };
  assert.notEqual(hashAuditEvent(base, "a".repeat(32)), hashAuditEvent({ ...base, action: "logout" }, "a".repeat(32)));
});
