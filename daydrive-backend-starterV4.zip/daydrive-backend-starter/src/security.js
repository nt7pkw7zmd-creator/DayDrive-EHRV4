import { createHmac } from "node:crypto";

export function hashAuditEvent({ previousHash = "", occurredAt, actorUserId = "", actorRole, action, targetType = "", targetId = "", metadata = {} }, secret) {
  const canonical = JSON.stringify([previousHash, occurredAt, actorUserId, actorRole, action, targetType, targetId, metadata]);
  return createHmac("sha256", secret).update(canonical).digest("hex");
}

export function safeAuditMetadata(input = {}) {
  // Never put passwords, session IDs, free-text clinical data, or full chart payloads in audit metadata.
  const allowed = {};
  for (const key of ["assignmentId", "studentId", "trainingCode", "resultCount", "reason"]) {
    if (input[key] !== undefined) allowed[key] = String(input[key]).slice(0, 120);
  }
  return allowed;
}

export function canReadAssignment(user, assignment) {
  if (!user || !assignment) return false;
  if (user.role === "admin") return true;
  if (user.role === "instructor") return assignment.created_by === user.id;
  if (user.role === "student") return assignment.assigned_to === user.id;
  return false;
}

export function canGradeAssignment(user, assignment) {
  return Boolean(user && assignment &&
    (user.role === "admin" || (user.role === "instructor" && assignment.created_by === user.id)));
}
