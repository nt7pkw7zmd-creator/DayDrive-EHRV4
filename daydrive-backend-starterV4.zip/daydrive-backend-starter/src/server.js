import "dotenv/config";
import app from "./app.js";

const port = Number(process.env.PORT || 3000);
if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  throw new Error("SESSION_SECRET must be set to at least 32 characters");
}
app.listen(port, "0.0.0.0", () => console.log(`DayDrive EHR API listening on ${port}`));
