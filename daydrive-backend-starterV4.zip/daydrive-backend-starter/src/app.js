import express from "express";
import session from "express-session";
import connectPgSimple from "connect-pg-simple";
import helmet from "helmet";
import { randomBytes, timingSafeEqual } from "node:crypto";
import rateLimit from "express-rate-limit";
import { pool } from "./db.js";
import authRoutes from "./routes/auth.js";
import assignmentRoutes from "./routes/assignments.js";

const PgSession = connectPgSimple(session);
const app = express();
const production = process.env.NODE_ENV === "production";
const cookieName = process.env.SESSION_COOKIE_NAME || "daydrive.sid";

app.disable("x-powered-by");
app.set("trust proxy", production ? 1 : false);
app.use(helmet({ contentSecurityPolicy: { directives: { defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'"], imgSrc: ["'self'", "data:"] } } }));
app.use(express.json({ limit: "32kb" }));
app.use(session({
  name: cookieName,
  store: new PgSession({ pool, tableName: "user_sessions", createTableIfMissing: false }),
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  rolling: true,
  cookie: { httpOnly: true, secure: production, sameSite: "lax", maxAge: 15 * 60 * 1000, path: "/" }
}));

app.get("/api/csrf", (req, res) => {
  if (!req.session.csrfToken) req.session.csrfToken = randomBytes(32).toString("hex");
  res.json({ csrfToken: req.session.csrfToken });
});
app.use("/api", (req, res, next) => {
  if (["GET", "HEAD", "OPTIONS"].includes(req.method)) return next();
  const expected = req.session?.csrfToken;
  const supplied = req.get("x-csrf-token");
  if (typeof expected !== "string" || typeof supplied !== "string") {
    return res.status(403).json({ error: "CSRF token required" });
  }
  const a = Buffer.from(expected);
  const b = Buffer.from(supplied);
  if (a.length !== b.length || !timingSafeEqual(a, b)) {
    return res.status(403).json({ error: "Invalid CSRF token" });
  }
  next();
});
app.use("/api/auth/login", rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: "draft-7", legacyHeaders: false }));
app.use("/api/auth", authRoutes);
app.use("/api/assignments", assignmentRoutes);
app.get("/health", (_req, res) => res.json({ ok: true, service: "daydrive-ehr-api" }));

app.use((err, _req, res, _next) => {
  // Avoid leaking SQL, stack traces, or internal details to clients.
  console.error(err);
  res.status(500).json({ error: "Internal server error" });
});
export default app;
