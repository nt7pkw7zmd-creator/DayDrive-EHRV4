import { Router } from "express";
import { z } from "zod";
import { pool } from "../db.js";
import { writeAudit } from "../audit.js";
import { requireAuth, requireRole } from "../middleware/auth.js";
import { canGradeAssignment, canReadAssignment } from "../security.js";

const router = Router();
const createSchema = z.object({
  title: z.string().trim().min(1).max(100),
  instructions: z.string().trim().min(1).max(5000),
  patientId: z.string().uuid(),
  assignedTo: z.string().uuid(),
  points: z.number().int().min(1).max(1000),
  dueDate: z.string().date().optional()
});
const submissionSchema = z.object({ text: z.string().trim().min(1).max(10000) });
const gradeSchema = z.object({
  grade: z.number().int().min(0),
  feedback: z.string().max(500).optional().default("")
});

router.use(requireAuth);

router.get("/", async (req, res, next) => {
  try {
    let sql, values = [];
    if (req.user.role === "admin") {
      sql = "SELECT * FROM assignments ORDER BY created_at DESC";
    } else if (req.user.role === "instructor") {
      sql = "SELECT * FROM assignments WHERE created_by=$1 ORDER BY created_at DESC";
      values = [req.user.id];
    } else {
      sql = "SELECT * FROM assignments WHERE assigned_to=$1 ORDER BY created_at DESC";
      values = [req.user.id];
    }
    const result = await pool.query(sql, values);
    res.json({ assignments: result.rows });
  } catch (error) { next(error); }
});

router.post("/", requireRole("instructor"), async (req, res, next) => {
  try {
    const parsed = createSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "Invalid assignment", details: parsed.error.flatten() });
    const data = parsed.data;
    const student = await pool.query("SELECT id FROM app_users WHERE id=$1 AND role='student' AND active=true", [data.assignedTo]);
    const patient = await pool.query("SELECT id FROM training_patients WHERE id=$1", [data.patientId]);
    if (!student.rowCount || !patient.rowCount) return res.status(400).json({ error: "Student or training case unavailable" });
    const result = await pool.query(
      `INSERT INTO assignments (title,instructions,patient_id,assigned_to,created_by,points,due_date)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [data.title,data.instructions,data.patientId,data.assignedTo,req.user.id,data.points,data.dueDate || null]
    );
    await writeAudit({ actor: req.user, action: "assignment_created", targetType: "assignment", targetId: result.rows[0].id, metadata: { studentId: data.assignedTo } });
    res.status(201).json({ assignment: result.rows[0] });
  } catch (error) { next(error); }
});

router.post("/:id/submission", requireRole("student"), async (req, res, next) => {
  try {
    const parsed = submissionSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "Invalid submission" });
    const result = await pool.query(
      `UPDATE assignments SET submission_text=$1, submitted_at=now(), grade=NULL, feedback='', graded_at=NULL
       WHERE id=$2 AND assigned_to=$3 RETURNING *`,
      [parsed.data.text, req.params.id, req.user.id]
    );
    if (!result.rowCount) return res.status(404).json({ error: "Assignment not found" });
    await writeAudit({ actor: req.user, action: "assignment_submitted", targetType: "assignment", targetId: req.params.id });
    res.json({ assignment: result.rows[0] });
  } catch (error) { next(error); }
});

router.post("/:id/grade", requireRole("instructor", "admin"), async (req, res, next) => {
  try {
    const parsed = gradeSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "Invalid grade" });
    const found = await pool.query("SELECT * FROM assignments WHERE id=$1", [req.params.id]);
    const assignment = found.rows[0];
    if (!assignment || !canGradeAssignment(req.user, assignment)) return res.status(404).json({ error: "Assignment not found" });
    if (!assignment.submitted_at) return res.status(409).json({ error: "Student has not submitted this assignment" });
    if (parsed.data.grade > assignment.points) return res.status(400).json({ error: "Grade exceeds points possible" });
    const result = await pool.query(
      "UPDATE assignments SET grade=$1, feedback=$2, graded_at=now() WHERE id=$3 RETURNING *",
      [parsed.data.grade, parsed.data.feedback, req.params.id]
    );
    await writeAudit({ actor: req.user, action: "assignment_graded", targetType: "assignment", targetId: req.params.id });
    res.json({ assignment: result.rows[0] });
  } catch (error) { next(error); }
});

export default router;
