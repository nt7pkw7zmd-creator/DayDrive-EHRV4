import { Router } from "express";
import argon2 from "argon2";
import { z } from "zod";
import { pool } from "../db.js";
import { writeAudit } from "../audit.js";
import { requireAuth } from "../middleware/auth.js";

const router = Router();
const loginSchema = z.object({
  username: z.string().trim().min(3).max(64).transform(v => v.toLowerCase()),
  password: z.string().min(1).max(256)
});

router.post("/login", async (req, res, next) => {
  try {
    const parsed = loginSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "Invalid sign-in details" });
    const { username, password } = parsed.data;
    const result = await pool.query(
      "SELECT id, username, display_name, password_hash, role, active FROM app_users WHERE username=$1",
      [username]
    );
    const user = result.rows[0];
    const valid = user && user.active && await argon2.verify(user.password_hash, password);
    if (!valid) {
      await writeAudit({ action: "login_failed", metadata: { reason: "invalid_credentials" } });
      return res.status(401).json({ error: "Sign-in failed" });
    }
    req.session.regenerate(async (err) => {
      if (err) return next(err);
      try {
        req.session.user = { id: user.id, username: user.username, name: user.display_name, role: user.role };
        await pool.query("UPDATE app_users SET last_login_at=now() WHERE id=$1", [user.id]);
        await writeAudit({ actor: req.session.user, action: "login" });
        res.json({ user: req.session.user });
      } catch (callbackError) { next(callbackError); }
    });
  } catch (error) { next(error); }
});

router.post("/logout", requireAuth, async (req, res, next) => {
  try {
    const actor = req.user;
    await writeAudit({ actor, action: "logout" });
    req.session.destroy(err => {
      if (err) return next(err);
      res.clearCookie(process.env.SESSION_COOKIE_NAME || "daydrive.sid");
      res.status(204).end();
    });
  } catch (error) { next(error); }
});

router.get("/me", requireAuth, (req, res) => res.json({ user: req.user }));
export default router;
