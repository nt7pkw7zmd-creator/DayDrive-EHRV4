import { pool } from "./db.js";
import { hashAuditEvent, safeAuditMetadata } from "./security.js";

export async function writeAudit({ actor = null, action, targetType = null, targetId = null, metadata = {} }) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    // Serialize hash-chain writes to keep a single ordered chain.
    await client.query("LOCK TABLE audit_events IN SHARE ROW EXCLUSIVE MODE");
    const prev = await client.query("SELECT event_hash FROM audit_events ORDER BY id DESC LIMIT 1");
    const occurredAt = new Date().toISOString();
    const clean = safeAuditMetadata(metadata);
    const event = {
      previousHash: prev.rows[0]?.event_hash || "",
      occurredAt,
      actorUserId: actor?.id || "",
      actorRole: actor?.role || "system",
      action,
      targetType: targetType || "",
      targetId: targetId || "",
      metadata: clean
    };
    const secret = process.env.AUDIT_HMAC_SECRET;
    if (!secret || secret.length < 32) throw new Error("Audit signing secret must be at least 32 characters");
    const eventHash = hashAuditEvent(event, secret);
    await client.query(
      `INSERT INTO audit_events
       (occurred_at, actor_user_id, actor_role, action, target_type, target_id, metadata, previous_hash, event_hash)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
      [occurredAt, actor?.id || null, actor?.role || "system", action, targetType, targetId, clean, event.previousHash, eventHash]
    );
    await client.query("COMMIT");
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}
