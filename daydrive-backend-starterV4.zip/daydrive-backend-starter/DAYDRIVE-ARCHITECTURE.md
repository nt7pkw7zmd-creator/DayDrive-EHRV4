# DayDrive EHR target architecture

```text
Browser UI (orange/blue)
  | HTTPS + CSRF token + HttpOnly session cookie
  v
Express API (server-enforced auth + authorization)
  | parameterized SQL; least-privilege DB identity
  v
PostgreSQL
  |- app_users
  |- training_patients (fictional case_data only)
  |- assignments (created_by + assigned_to)
  |- audit_events (append-only trigger + HMAC chain)
  `- user_sessions
```

## Trust boundaries

- The browser is untrusted. UI hiding is convenience only; every protected route checks the server session and role.
- The API never accepts `created_by`, role, or actor identity from a client request. It derives the actor from the server session.
- Assignment list queries are scoped in SQL, not filtered after sending all rows to the browser.
- The database runtime account is not a table owner and cannot update/delete audit events.
- Audit metadata is allow-listed and excludes passwords, session IDs, and free-text chart content.
- Patient records must be generated fictional scenarios with an explicit `fictional_training_case` marker.

## Deployment sequence

1. Provision managed PostgreSQL and a separate API host/container.
2. Apply migrations with a dedicated owner role; run API with a least-privilege role.
3. Set secrets through the hosting provider's secret manager; require HTTPS and secure cookies.
4. Configure a single trusted reverse proxy, backups, monitoring, rate limits, and alerting.
5. Run unit + integration + authorization tests against a disposable test database.
6. Connect the existing UI to `/api/*`; remove localStorage as an authority for users, roles, assignments, or audit records.
7. Perform a security review before sharing with students.
