# DayDrive EHR — backend starter

This is the first server-side architecture step for the **educational training** edition of DayDrive EHR. It is designed for fictional patients and simulated records only. It is not a clinical system and makes no HIPAA-compliance claim.

## What this starter adds

- PostgreSQL as the central database (not browser `localStorage`).
- Server-side sessions stored in PostgreSQL; `HttpOnly`, `SameSite=Lax`, secure-in-production cookies.
- Argon2 password verification, login rate limiting, Helmet security headers, request-size limits, and synchronizer-token CSRF protection for state-changing API calls.
- Server-enforced roles (`admin`, `instructor`, `student`).
- Instructor assignment visibility and grading restricted to records created by that instructor; students can only view/submit their own assignments; admins can review all.
- Append-only audit table, mutation-blocking trigger, restricted runtime-role grants, and an HMAC hash chain for detecting event changes.
- Automated unit tests for the core assignment authorization rules.

The current v2 HTML remains a browser-only prototype. This backend is a separate foundation; the HTML has **not** yet been wired to these API endpoints. The browser-side app must not be treated as secure until that integration is complete.

## Requirements

- Node.js 20+
- PostgreSQL 16+
- A reverse proxy / hosting environment that terminates HTTPS in production

## Local setup

1. Copy `.env.example` to `.env`. Generate unique random `SESSION_SECRET` and `AUDIT_HMAC_SECRET` values, each at least 32 characters; do not reuse either secret. Never commit `.env`.
2. Create a PostgreSQL database and a dedicated migration/owner account. Apply `migrations/001_initial.sql` using that account.
3. Create a separate runtime login role. Grant it only the permissions shown at the bottom of the migration; it must **not** own the schema or tables. Set `DATABASE_URL` to this restricted role.
4. Create the session table (the session adapter can create it at first start, or provision it in advance). Confirm the runtime role can create/use the session table or create it separately and grant only the required session permissions.
5. Grant the runtime role `SELECT, INSERT, UPDATE, DELETE` on `user_sessions` as shown in the migration comments.
6. Run `npm install`, then `npm test`, then `npm run check`.
7. Start with `npm start`. Check `GET /health`.

## First administrator provisioning

There is no public self-service admin registration route. After the migration and restricted DB role are ready, provision the first admin once using the CLI:

1. Set `BOOTSTRAP_ADMIN_USERNAME`, `BOOTSTRAP_ADMIN_NAME`, and `BOOTSTRAP_ADMIN_PASSWORD` in the operator's protected environment (password must be 14+ characters).
2. Run `npm run bootstrap:admin` using the restricted runtime DB URL.
3. Unset those three environment variables immediately.

The script refuses to run if an admin already exists and stores only an Argon2id password hash. Do not put bootstrap credentials in source control, shell history, tickets, or chat.

## API outline

- `GET /api/csrf` — obtain a CSRF token for the browser client.
- `POST /api/auth/login` — JSON `{ "username": "...", "password": "..." }`.
- `GET /api/auth/me` — current server session.
- `POST /api/auth/logout` — sign out (requires CSRF token).
- `GET /api/assignments` — role-scoped list.
- `POST /api/assignments` — instructor creates an assignment.
- `POST /api/assignments/:id/submission` — assigned student submits.
- `POST /api/assignments/:id/grade` — creator instructor or admin grades.

First call `GET /api/csrf`, then send its `csrfToken` as `x-csrf-token` on state-changing calls. The token is tied to the server session.

## Important implementation notes / known gaps

- This is a starter scaffold, not a finished deployable product. The HTML prototype has not been migrated to API calls.
- Add a secure one-time admin bootstrap CLI, password reset/invitation flow, account deactivation/session revocation, and comprehensive integration tests.
- The audit hash chain is detectable tamper evidence, not absolute immutability. A database superuser or compromised host can alter the database and signing secret. Production should export audit events to separately administered immutable/WORM storage and rotate signing secrets.
- The SQL trigger blocks row UPDATE/DELETE, but table owners/superusers can disable triggers. Keep runtime credentials separate from migration ownership and restrict infrastructure administration.
- No package installation or live HTTP / PostgreSQL test was performed in this environment.
- Add database backup/restore drills, monitoring, dependency scanning, secrets management, HTTPS, secure headers/CSP review, and operational incident procedures before any real deployment.
- Never load real patient information into this training system.
