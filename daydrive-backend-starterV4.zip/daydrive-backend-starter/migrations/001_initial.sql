-- Apply as a dedicated migration/owner role, not the runtime application role.
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE app_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  username text NOT NULL UNIQUE CHECK (username = lower(username)),
  display_name text NOT NULL,
  password_hash text NOT NULL,
  role text NOT NULL CHECK (role IN ('admin','instructor','student')),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  last_login_at timestamptz
);

CREATE TABLE training_patients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  training_code text NOT NULL UNIQUE,
  case_data jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (case_data->>'fictional_training_case' = 'true')
);

CREATE TABLE assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title varchar(100) NOT NULL,
  instructions text NOT NULL,
  patient_id uuid NOT NULL REFERENCES training_patients(id),
  assigned_to uuid NOT NULL REFERENCES app_users(id),
  created_by uuid NOT NULL REFERENCES app_users(id),
  points integer NOT NULL CHECK (points BETWEEN 1 AND 1000),
  due_date date,
  submission_text text,
  submitted_at timestamptz,
  grade integer,
  feedback varchar(500) NOT NULL DEFAULT '',
  graded_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (grade IS NULL OR (grade >= 0 AND grade <= points)),
  CHECK ((submission_text IS NULL) = (submitted_at IS NULL))
);
CREATE INDEX assignments_student_idx ON assignments(assigned_to, created_at DESC);
CREATE INDEX assignments_instructor_idx ON assignments(created_by, created_at DESC);

CREATE TABLE user_sessions (
  sid varchar NOT NULL PRIMARY KEY,
  sess json NOT NULL,
  expire timestamp(6) NOT NULL
);
CREATE INDEX user_sessions_expire_idx ON user_sessions(expire);

CREATE TABLE audit_events (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  occurred_at timestamptz NOT NULL DEFAULT now(),
  actor_user_id uuid REFERENCES app_users(id),
  actor_role text NOT NULL,
  action text NOT NULL,
  target_type text,
  target_id text,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  previous_hash text,
  event_hash text NOT NULL
);
CREATE INDEX audit_events_time_idx ON audit_events(occurred_at DESC);

-- Defense in depth: prevent UPDATE/DELETE for every database role, including accidental admin UI code.
CREATE FUNCTION deny_audit_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'audit_events is append-only';
END $$;
CREATE TRIGGER audit_events_no_update
  BEFORE UPDATE OR DELETE ON audit_events
  FOR EACH ROW EXECUTE FUNCTION deny_audit_mutation();

-- Runtime-role grants. Create this role separately; it must not own the tables/schema.
-- Replace the password outside source control.
-- CREATE ROLE daydrive_app LOGIN PASSWORD '...';
-- GRANT CONNECT ON DATABASE daydrive TO daydrive_app;
-- GRANT USAGE ON SCHEMA public TO daydrive_app;
-- GRANT SELECT, INSERT, UPDATE ON app_users, assignments, training_patients TO daydrive_app;
-- GRANT SELECT, INSERT, UPDATE, DELETE ON user_sessions TO daydrive_app;
-- GRANT SELECT, INSERT ON audit_events TO daydrive_app;
-- GRANT USAGE, SELECT ON SEQUENCE audit_events_id_seq TO daydrive_app;
-- REVOKE UPDATE, DELETE, TRUNCATE ON audit_events FROM daydrive_app;
